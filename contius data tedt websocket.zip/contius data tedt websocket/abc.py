import asyncio 
import nest_asyncio
import websockets

async def handler(websocket, path):
    data = await websocket.recv()
    reply = f"Data received as: {data}!"
    await websocket.send(reply)

async def start_server():
    server = await websockets.serve(handler, "localhost", 8000)
    await server.wait_closed()

nest_asyncio.apply()
asyncio.get_event_loop().run_until_complete(start_server())
